<?php
session_start();
// Ensure database connection is available
include "includes/db.php";

$error_msg = "";
$success_msg = "";

// 1. CHECK FOR REGISTRATION SUCCESS
// This catches the redirect from signup.php?success=1
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success_msg = "Registration successful! Please log in.";
}

// 2. HANDLE LOGIN FORM SUBMISSION
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error_msg = "Please enter both email and password.";
    } else {
        // Use Prepared Statements for security (Prevents SQL Injection)
        $stmt = $conn->prepare("SELECT user_id, full_name, role, email, password, status FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verify the Hashed Password
            if (password_verify($password, $user['password'])) {
                // Set Session Variables
                $_SESSION['user'] = [
                    'user_id'   => $user['user_id'],
                    'full_name' => $user['full_name'],
                    'role'      => $user['role'],
                    'email'     => $user['email'],
                    'status'    => $user['status']
                ];
                $_SESSION['logged_in'] = true;

                // Smart Routing based on User Role
                $role = strtoupper(trim($user['role'])); // Standardize to uppercase
                
                // Determine destination folder
                switch ($role) {
                    case 'ADMIN':
                        $redirect_url = 'ADMIN/dashboard.php';
                        break;
                    case 'DRIVER':
                        $redirect_url = 'USER/dashboard.php';
                        break;
                    case 'STAFF':
                        $redirect_url = 'STAFF/dashboard.php';
                        break;
                    case 'EMPLOYEE':
                        $redirect_url = 'EMPLOYEE/dashboard.php';
                        break;
                    default:
                        $redirect_url = 'USER/dashboard.php'; // Fallback for standard users
                        break;
                }

                header("Location: " . $redirect_url);
                exit;
            } else {
                $error_msg = "Invalid password. Please try again.";
            }
        } else {
            $error_msg = "No account found with this email address.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login · Logistics II</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: Arial, sans-serif; background: #fff; }
  </style>
</head>

<body class="min-h-screen flex flex-col items-center justify-center bg-white">

  <div class="text-center mb-8">
    <div class="w-16 h-16 mx-auto bg-green-600 rounded-full flex items-center justify-center">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
        stroke-width="1.5" stroke="currentColor" class="size-9 text-white">
        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0 1.106 1.106 0 0 0-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12"/>
      </svg>
    </div>
    <h1 class="mt-4 text-2xl font-bold text-gray-800">Fleet and Transportation Operations</h1>
    <p class="text-gray-600">Secure access to your Fleet Management System</p>
  </div>

  <div class="bg-white shadow-lg rounded-lg w-full max-w-md p-6 border-2 border-green-600 shadow-green-200">
    <h2 class="text-xl font-semibold text-center mb-2 text-green-700">Log In</h2>
    <p class="text-sm text-gray-600 text-center mb-4">Enter your credentials to access the dashboard</p>

    <?php if (!empty($success_msg)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4 text-center text-sm">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline"><?php echo $success_msg; ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 text-center text-sm">
            <strong class="font-bold">Error!</strong>
            <span class="block sm:inline"><?php echo $error_msg; ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="" class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-black-700">Email Address</label>
        <input name="email" id="email" type="email" placeholder="yourexample@domain.com" required
          class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-green-600 focus:border-green-600 shadow-sm shadow-green-100 transition-all">
      </div>

      <div>
        <label class="block text-sm font-medium text-black-700">Password</label>
        <input name="password" id="password" type="password" placeholder="Enter your password..." required
          class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-green-600 focus:border-green-600 shadow-sm shadow-green-100 transition-all">
      </div>

      <button type="submit"
        class="w-full py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition font-semibold shadow-md">
        Log In
      </button>

      <div class="mt-4 text-center space-y-2">
          <p class="text-sm text-gray-500">
            <a href="#" class="text-green-600 hover:underline">Forgot your password?</a>
          </p>
          
          <p class="text-black-600">
            Don't have an account?
            <a href="signup.php" class="text-green-600 hover:underline font-medium">Sign Up</a>
          </p>
      </div>
    </form>
  </div>

</body>
</html>