<?php
// FILE: ADMIN/includes/functions.php

// 1. AUTO-CONNECT TO DATABASE
if (!isset($conn)) {
    require_once __DIR__ . '/db.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2️⃣ VEHICLES
function getVehicles() {
    global $conn;
    $sql = "SELECT * FROM vehicles ORDER BY vehicle ASC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

// 3️⃣ DRIVERS
function getDrivers() {
    global $conn;
    $sql = "SELECT * FROM drivers ORDER BY full_name ASC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

// 4️⃣ AVAILABLE DRIVERS
function getAvailableDrivers() {
    global $conn;
    $sql = "SELECT * FROM drivers WHERE status='Active' ORDER BY full_name ASC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

// 5️⃣ TRIPS / DISPATCH ASSIGNMENTS
function getTrips() {
    global $conn;
    // Removed v.lat/v.lng to prevent crashes if columns missing
    $sql = "SELECT t.id, v.vehicle, v.model, v.type, d.full_name AS driver, t.route, t.dispatch_date, t.return_date, t.status AS availability, t.trip_code
            FROM trips t
            JOIN vehicles v ON t.vehicle_id = v.id
            LEFT JOIN drivers d ON t.driver_id = d.id
            ORDER BY t.dispatch_date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getTripSchedules() {
    global $conn;
    $sql = "SELECT t.id, v.vehicle, d.full_name AS driver, t.route, t.dispatch_date AS date
            FROM trips t
            JOIN vehicles v ON t.vehicle_id = v.id
            LEFT JOIN drivers d ON t.driver_id = d.id
            ORDER BY t.dispatch_date ASC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getDispatchAssignments() {
    global $conn;
    if ($conn->query("SHOW TABLES LIKE 'dispatches'")->num_rows == 0) return [];

    $sql = "SELECT d.id, v.vehicle, v.model, v.type, d.driver_id, dr.full_name AS driver, d.status, d.dispatch_date, d.route, d.availability
            FROM dispatches d
            JOIN vehicles v ON d.vehicle_id = v.id
            LEFT JOIN drivers dr ON d.driver_id = dr.id
            ORDER BY d.dispatch_date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function addVehicle($data) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO vehicles (plate, model, type, year, status, last_maintenance) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssiss", $data['plate'], $data['model'], $data['type'], $data['year'], $data['status'], $data['last_maintenance']);
    return $stmt->execute();
}

function updateVehicle($data) {
    global $conn;
    $stmt = $conn->prepare("UPDATE vehicles SET plate = ?, model = ?, type = ?, year = ?, status = ?, last_maintenance = ? WHERE id = ?");
    $stmt->bind_param("sssissi", $data['plate'], $data['model'], $data['type'], $data['year'], $data['status'], $data['last_maintenance'], $data['id']);
    return $stmt->execute();
}

function deactivateVehicle($id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE vehicles SET status = 'Inactive' WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// 8️⃣ MAINTENANCE RECORDS
function getMaintenanceRecords() {
    global $conn;
    $sql = "SELECT m.id, v.plate, v.vehicle, m.type, m.date, m.cost, m.status, m.priority, m.notes
            FROM maintenance m
            JOIN vehicles v ON m.vehicle_id = v.id
            ORDER BY m.date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function addMaintenance($data) {
    global $conn;
    $cost = isset($data['cost']) ? $data['cost'] : 0.00;
    $stmt = $conn->prepare("INSERT INTO maintenance (vehicle_id, type, date, cost, notes, status, priority) VALUES (?, ?, ?, ?, ?, 'Pending', ?)");
    $stmt->bind_param("issdss", $data['vehicle_id'], $data['type'], $data['date'], $cost, $data['notes'], $data['priority']);
    return $stmt->execute();
}

function completeMaintenance($id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE maintenance SET status = 'Completed' WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

function getVehicleIdByPlate($plate) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM vehicles WHERE plate = ?");
    $stmt->bind_param("s", $plate);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row['id'] ?? null;
}

// 9️⃣ FUEL EXPENSES
function getFuelExpenses() {
    global $conn;
    $sql = "SELECT fe.id, fe.vehicle_id, v.plate AS vehicle, fe.date, fe.liters, fe.cost, d.full_name AS driver
            FROM fuel_expenses fe
            LEFT JOIN vehicles v ON fe.vehicle_id = v.id
            LEFT JOIN drivers d ON fe.driver_id = d.id
            ORDER BY fe.date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

// 10️⃣ APPROVALS
function getApprovals() {
    global $conn;
    $sql = "SELECT a.id, v.vehicle, a.type, a.request_date AS date, a.cost AS amount, a.status
            FROM maintenance_approvals a
            JOIN vehicles v ON a.vehicle_id = v.id
            ORDER BY a.request_date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function approveRequestById($id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE maintenance_approvals SET status = 'Approved' WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

function rejectRequestById($id, $reason) {
    global $conn;
    $stmt = $conn->prepare("UPDATE maintenance_approvals SET status = 'Rejected', rejection_reason = ? WHERE id = ?");
    $stmt->bind_param("si", $reason, $id);
    return $stmt->execute();
}

function insertApprovedMaintenance($approvalId) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO maintenance (vehicle_id, type, date, cost, status, notes)
        SELECT vehicle_id, type, request_date, cost, 'In Progress', notes
        FROM maintenance_approvals WHERE id = ?");
    $stmt->bind_param("i", $approvalId);
    return $stmt->execute();
}

// --- FIXED COMPLIANCE RECORDS ---
function getComplianceRecords() {
    global $conn;
    $sql = "SELECT 
                c.id, 
                v.plate AS vehicle, 
                c.document_type, 
                c.issue_date,
                c.expiry_date,
                CASE 
                    WHEN c.expiry_date < CURDATE() THEN 'Expired'
                    WHEN c.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 'Expiring Soon'
                    ELSE 'Valid' 
                END AS status
            FROM compliance_documents c
            JOIN vehicles v ON c.vehicle_id = v.id
            ORDER BY c.expiry_date ASC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

// 11️⃣ NOTIFICATIONS
function getNotifications() {
    global $conn;
    $sql = "SELECT id, title, message, link, color, icon, 
                   read_status AS `read`, 
                   created_at AS `time`,
                   'info' AS `type` 
            FROM notifications 
            ORDER BY created_at DESC LIMIT 20";
    $res = $conn->query($sql);
    
    $notifications = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $row['time'] = date('M d, H:i', strtotime($row['time']));
            $notifications[] = $row;
        }
    }
    return $notifications;
}

function getUnreadNotificationCount() {
    global $conn;
    $sql = "SELECT COUNT(*) AS unread FROM notifications WHERE read_status = 0";
    $res = $conn->query($sql);
    $row = $res ? $res->fetch_assoc() : ['unread' => 0];
    return $row['unread'];
}

// 12️⃣ KPI DATA (Fixed & Optimized)
function getKPIData() {
    global $conn;
    
    $totalVehicles = $conn->query("SELECT COUNT(*) FROM vehicles")->fetch_row()[0] ?? 0;
    $activeVehicles = $conn->query("SELECT COUNT(*) FROM vehicles WHERE status='Available'")->fetch_row()[0] ?? 0;
    $inactiveVehicles = $conn->query("SELECT COUNT(*) FROM vehicles WHERE status='Inactive'")->fetch_row()[0] ?? 0;
    $maintenanceDue = $conn->query("SELECT COUNT(*) FROM vehicles WHERE status='Under Maintenance'")->fetch_row()[0] ?? 0;
    $availableDrivers = $conn->query("SELECT COUNT(*) FROM drivers WHERE status='Active'")->fetch_row()[0] ?? 0;
    
    // Check if dispatches table exists before counting
    $activeTrips = 0;
    if ($conn->query("SHOW TABLES LIKE 'dispatches'")->num_rows > 0) {
        $activeTrips = $conn->query("SELECT COUNT(*) FROM dispatches WHERE status='Assigned'")->fetch_row()[0] ?? 0;
    }

    return [
        'total_vehicles' => $totalVehicles,
        'active_vehicles' => $activeVehicles,
        'inactive_vehicles' => $inactiveVehicles,
        'maintenance_due' => $maintenanceDue,
        'available_drivers' => $availableDrivers,
        'active_trips' => $activeTrips,
    ];
}

function getStatusClass($status) {
    return match($status) {
        'Available', 'Active', 'Completed' => 'bg-green-100 text-green-800',
        'Assigned', 'On Duty', 'In Progress' => 'bg-blue-100 text-blue-800',
        'Maintenance', 'Pending', 'Inactive' => 'bg-yellow-100 text-yellow-800',
        default => 'bg-gray-100 text-gray-800',
    };
}

function getVehicleById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM vehicles WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function addFuelExpense($vehicle_id, $date, $liters, $cost, $driver_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO fuel_expenses (vehicle_id, date, liters, cost, driver_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isddi", $vehicle_id, $date, $liters, $cost, $driver_id);
    return $stmt->execute();
}

function getDriverProfiles() {
    global $conn;
    $sql = "SELECT d.id, d.full_name AS name, d.license, u.email, d.address, d.emergency_contact, d.blood_type, d.status, d.join_date, d.expiry, d.rating, d.safety_score, d.on_time_rate, d.total_trips, d.total_distance, d.incidents
            FROM drivers d LEFT JOIN users u ON d.user_id = u.user_id ORDER BY d.full_name ASC";
    $res = $conn->query($sql);
    $drivers = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    foreach ($drivers as &$driver) {
        $driver['certifications'] = ['Defensive Driving', 'First Aid', 'Hazard Handling'];
    }
    return $drivers;
}

function getIncidentCases() {
    global $conn;
    $sql = "SELECT ic.*, d.full_name AS driver, v.plate AS vehicle FROM incident_cases ic
            LEFT JOIN drivers d ON ic.driver_id = d.id LEFT JOIN vehicles v ON ic.vehicle_id = v.id ORDER BY ic.date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getDriverBehaviorData() {
    global $conn;
    $sql = "SELECT db.*, d.full_name AS driver FROM driver_behavior db JOIN drivers d ON db.driver_id = d.id ORDER BY db.score DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getBehaviorIncidents($limit = 5) {
    global $conn;
    $sql = "SELECT bi.*, d.full_name AS driver FROM behavior_incidents bi JOIN drivers d ON bi.driver_id = d.id ORDER BY bi.date DESC LIMIT $limit";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getMonthlyBehaviorTrends($months = 6) {
    global $conn;
    $sql = "SELECT DATE_FORMAT(month_date, '%b %Y') AS month, total_speeding AS speeding, total_harsh_braking AS harsh_braking FROM monthly_behavior_trends ORDER BY month_date DESC LIMIT $months";
    $res = $conn->query($sql);
    $data = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    return array_reverse($data);
}

function getTripPerformanceReports($startDate = null, $endDate = null) {
    global $conn;
    $where = [];
    if ($startDate) $where[] = "t.dispatch_date >= '$startDate'";
    if ($endDate) $where[] = "t.dispatch_date <= '$endDate'";
    $whereSql = $where ? "WHERE " . implode(' AND ', $where) : "";

    $sql = "SELECT t.id AS trip_id, t.trip_code, t.route, t.dispatch_date AS date, t.return_date, t.departure_time, t.arrival_time, t.start_location, t.end_location, t.planned_distance, t.actual_distance, t.planned_duration, t.actual_duration, t.fuel_used, t.fuel_cost, t.status, t.on_time_percentage, t.idle_time, t.route_deviation, t.notes, v.plate AS vehicle, v.model AS vehicle_model, d.full_name AS driver, d.rating AS driver_rating
            FROM trips t LEFT JOIN vehicles v ON t.vehicle_id = v.id LEFT JOIN drivers d ON t.driver_id = d.id $whereSql ORDER BY t.dispatch_date DESC";
    $res = $conn->query($sql);
    $trips = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $row['on_time_percentage'] = $row['on_time_percentage'] ?? ($row['status'] === 'On-Time' ? 100 : 0);
            $trips[] = $row;
        }
    }
    return $trips;
}

function getTripStatistics($startDate = null, $endDate = null) {
    global $conn;
    $where = [];
    if ($startDate) $where[] = "dispatch_date >= '$startDate'";
    if ($endDate) $where[] = "dispatch_date <= '$endDate'";
    $whereSql = $where ? "WHERE " . implode(' AND ', $where) : "";
    $sql = "SELECT COUNT(*) AS total_trips, SUM(CASE WHEN status = 'On-Time' THEN 1 ELSE 0 END) AS on_time_trips, SUM(CASE WHEN status = 'Delayed' THEN 1 ELSE 0 END) AS delayed_trips, SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_trips, SUM(actual_distance) AS total_distance, SUM(fuel_used) AS total_fuel FROM trips $whereSql";
    $res = $conn->query($sql);
    return $res ? $res->fetch_assoc() : ['total_trips'=>0];
}

function getTransportExpenses() {
    global $conn;
    $sql = "SELECT e.expense_id, e.date, e.category, e.amount, e.description, COALESCE(v.plate, 'N/A') AS vehicle, COALESCE(d.full_name, 'Unassigned') AS driver
            FROM transport_expenses e LEFT JOIN vehicles v ON e.vehicle_id = v.id LEFT JOIN drivers d ON e.driver_id = d.id ORDER BY e.date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getTransportCostSummary() {
    global $conn;
    $sqlTotal = "SELECT SUM(amount) AS total_cost FROM transport_expenses";
    $totalCost = ($conn->query($sqlTotal)->fetch_assoc())['total_cost'] ?? 0;
    
    $sqlDays = "SELECT COUNT(DISTINCT DATE(date)) AS days FROM transport_expenses";
    $days = ($conn->query($sqlDays)->fetch_assoc())['days'] ?? 1;
    $avgDailyCost = $days ? $totalCost / $days : 0;

    $sqlTop = "SELECT category, SUM(amount) AS total FROM transport_expenses GROUP BY category ORDER BY total DESC LIMIT 3";
    $topCategories = [];
    $resTop = $conn->query($sqlTop);
    while ($row = $resTop->fetch_assoc()) { $topCategories[$row['category']] = $row['total']; }

    $sqlBreakdown = "SELECT category, SUM(amount) AS total FROM transport_expenses GROUP BY category";
    $categoryBreakdown = [];
    $resBd = $conn->query($sqlBreakdown);
    while ($row = $resBd->fetch_assoc()) { $categoryBreakdown[$row['category']] = $row['total']; }

    return ['total_cost' => $totalCost, 'avg_daily_cost' => $avgDailyCost, 'top_categories' => $topCategories, 'category_breakdown' => $categoryBreakdown, 'monthly_change' => 5];
}

function getFuelConsumptionTrends() {
    global $conn;
    $sql = "SELECT v.plate, v.vehicle, SUM(fe.liters) AS total_liters, SUM(fe.cost) AS total_cost FROM vehicles v LEFT JOIN fuel_expenses fe ON fe.vehicle_id = v.id GROUP BY v.id ORDER BY total_cost DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function getVehicleCostComparison() {
    global $conn;
    $sql = "SELECT v.plate, SUM(e.amount) AS total_cost FROM transport_expenses e JOIN vehicles v ON e.vehicle_id = v.id GROUP BY v.plate";
    $res = $conn->query($sql);
    $vehicleCosts = []; $total = 0; $count = 0;
    while ($row = $res->fetch_assoc()) {
        $vehicleCosts[$row['plate']] = (float)$row['total_cost'];
        $total += $row['total_cost']; $count++;
    }
    return ['vehicle_costs' => $vehicleCosts, 'fleet_average' => $count > 0 ? $total / $count : 0];
}

function getOptimizationInsights() {
    global $conn;
    $avgSql = "SELECT AVG(vehicle_total) AS fleet_average FROM (SELECT SUM(amount) AS vehicle_total FROM transport_expenses WHERE vehicle_id IS NOT NULL GROUP BY vehicle_id) t";
    $fleetAverage = ($conn->query($avgSql)->fetch_assoc())['fleet_average'] ?? 0;
    $sql = "SELECT v.id, v.plate, v.vehicle, COALESCE(SUM(te.amount),0) AS total_cost FROM vehicles v LEFT JOIN transport_expenses te ON te.vehicle_id = v.id GROUP BY v.id ORDER BY total_cost DESC";
    $res = $conn->query($sql);
    return ['fleet_average' => $fleetAverage, 'vehicles' => $res ? $res->fetch_all(MYSQLI_ASSOC) : []];
}

function getReservations() {
    global $conn;
    $sql = "SELECT r.id, v.plate AS vehicle, v.model, v.type, d.full_name AS driver, r.reserved_date, r.purpose, r.notes FROM reservations r LEFT JOIN vehicles v ON r.vehicle_id = v.id LEFT JOIN drivers d ON r.driver_id = d.id ORDER BY r.reserved_date DESC";
    $res = $conn->query($sql);
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
}

function assignDriverToReservation($reservationId, $driverId) {
    global $conn;
    $stmt = $conn->prepare("UPDATE reservations SET driver_id=? WHERE id=?");
    $stmt->bind_param("ii", $driverId, $reservationId);
    return $stmt->execute();
}

function updateReservationStatus($reservationId, $status) {
    global $conn;
    $stmt = $conn->prepare("UPDATE reservations SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $reservationId);
    return $stmt->execute();
}

function createReservation($data) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO reservations (vehicle_id, driver_id, reserved_date, purpose, notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $data['vehicle_id'], $data['driver_id'], $data['reserved_date'], $data['purpose'], $data['notes']);
    return $stmt->execute();
}
?>