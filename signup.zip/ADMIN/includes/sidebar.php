<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Sidebar component - Left navigation with collapsible modules
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Define Base URL to prevent broken links (Fixes the ../ADMIN issues)
$base_url = '/ALLCAPS-MAIN/ADMIN';
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* Hide scrollbar but keep functionality */
    .no-scrollbar::-webkit-scrollbar {
        display: none;
    }
    .no-scrollbar {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
</style>

<div class="fixed left-0 top-0 w-0 md:w-[280px] h-screen bg-primary-green overflow-y-auto no-scrollbar z-40 transition-all duration-300" id="sidebar" style="background-color: #2D7A5C;">
    <div class="p-6 border-b border-white border-opacity-20">
        <a href="<?php echo $base_url; ?>/dashboard.php" class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                <i class="fas fa-truck text-white text-lg"></i>
            </div>
            <div>
                <div class="text-white font-bold text-sm">Logistics 2</div>
                <div class="text-white text-opacity-70 text-xs">Admin Panel</div>
            </div>
        </a>
    </div>

    <nav class="mt-6 pb-6">
        
        <a href="<?php echo $base_url; ?>/dashboard.php" class="nav-item text-white/80 px-5 py-3 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'dashboard' ? 'bg-white/10 border-l-white text-white' : ''; ?>">
            <i class="fas fa-grid-2"></i> 
            <span class="font-semibold">Dashboard</span>
        </a>

        <div class="mb-2">
            <div class="nav-item text-white/80 px-5 py-3 flex items-center justify-between cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo in_array($current_page, ['vehicle-registry', 'maintenance-tracker', 'fuel-expense-records', 'maintenance-approvals', 'compliance-licensing', 'predictive-maintenance']) ? 'bg-white/10' : ''; ?>" onclick="toggleModule('fleet')">
                <div class="flex items-center gap-3">
                    <i class="fas fa-truck"></i>
                    <span class="font-semibold">Fleet & Vehicle Management</span>
                </div>
                <i class="fas fa-chevron-down transition-transform duration-300 <?php echo in_array($current_page, ['vehicle-registry', 'maintenance-tracker', 'fuel-expense-records', 'maintenance-approvals', 'compliance-licensing', 'predictive-maintenance']) ? 'rotate-180' : ''; ?>" id="fleet-icon"></i>
            </div>
            <div class="<?php echo in_array($current_page, ['vehicle-registry', 'maintenance-tracker', 'fuel-expense-records', 'maintenance-approvals', 'compliance-licensing', 'predictive-maintenance']) ? '' : 'hidden'; ?> bg-white/5 overflow-hidden transition-all duration-300" id="fleet-submenu">
                
                <a href="<?php echo $base_url; ?>/module_1/vehicle-registry.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'vehicle-registry' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-car text-sm"></i>
                    <span class="text-sm">Vehicle Registry</span>
                </a>
                
                <a href="<?php echo $base_url; ?>/module_1/maintenance-tracker.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'maintenance-tracker' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-wrench text-sm"></i>
                    <span class="text-sm">Maintenance Tracker</span>
                </a>
                
                <a href="<?php echo $base_url; ?>/module_1/fuel-expense-records.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'fuel-expense-records' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-gas-pump text-sm"></i>
                    <span class="text-sm">Fuel & Expense Records</span>
                </a>
                
                <a href="<?php echo $base_url; ?>/module_1/compliance-licensing.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'compliance-licensing' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-file-contract text-sm"></i>
                    <span class="text-sm">Compliance & Licensing</span>
                </a>
            </div>
        </div>

        <div class="mb-2">
            <div class="nav-item text-white/80 px-5 py-3 flex items-center justify-between cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo in_array($current_page, ['tracker_live', 'reservation-management', 'availability-calendar']) ? 'bg-white/10' : ''; ?>" onclick="toggleModule('vrds')">
                <div class="flex items-center gap-3">
                    <i class="fas fa-calendar-check"></i>
                    <span class="font-semibold">Reservation & Dispatch</span>
                </div>
                <i class="fas fa-chevron-down transition-transform duration-300 <?php echo in_array($current_page, ['tracker_live', 'reservation-management', 'availability-calendar']) ? 'rotate-180' : ''; ?>" id="vrds-icon"></i>
            </div>
            <div class="<?php echo in_array($current_page, ['tracker_live', 'reservation-management', 'availability-calendar']) ? '' : 'hidden'; ?> bg-white/5 overflow-hidden transition-all duration-300" id="vrds-submenu">
                
                <a href="<?php echo $base_url; ?>/tracker_live.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'tracker_live' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-map-location-dot text-sm text-green-300"></i>
                    <span class="text-sm font-bold text-green-100">Live GPS Tracker</span>
                </a>

                <a href="<?php echo $base_url; ?>/module_2/reservation-management.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'reservation-management' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-tasks text-sm"></i>
                    <span class="text-sm">Reservation Management</span>
                </a>
                
            </div>
        </div>

        <div class="mb-2">
            <div class="nav-item text-white/80 px-5 py-3 flex items-center justify-between cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo in_array($current_page, ['incident-management', 'driver-profiles', 'trip-performance']) ? 'bg-white/10' : ''; ?>" onclick="toggleModule('performance')">
                <div class="flex items-center gap-3">
                    <i class="fas fa-user-check"></i>
                    <span class="font-semibold">Performance Monitoring</span>
                </div>
                <i class="fas fa-chevron-down transition-transform duration-300 <?php echo in_array($current_page, ['incident-management', 'driver-profiles', 'trip-performance']) ? 'rotate-180' : ''; ?>" id="performance-icon"></i>
            </div>
            <div class="<?php echo in_array($current_page, ['incident-management', 'driver-profiles', 'trip-performance']) ? '' : 'hidden'; ?> bg-white/5 overflow-hidden transition-all duration-300" id="performance-submenu">
                
                <a href="<?php echo $base_url; ?>/module_3/incident-management.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'incident-management' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-exclamation-triangle text-sm"></i>
                    <span class="text-sm">Incident Management</span>
                </a>
                
                <a href="<?php echo $base_url; ?>/module_3/driver-profiles.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'driver-profiles' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-id-card-alt text-sm"></i>
                    <span class="text-sm">Driver Profiles</span>
                </a>
                
                <a href="<?php echo $base_url; ?>/module_3/trip-performance.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'trip-performance' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-route text-sm"></i>
                    <span class="text-sm">Trip Performance</span>
                </a>
            </div>
        </div>

        <div class="mb-2">
            <div class="nav-item text-white/80 px-5 py-3 flex items-center justify-between cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo in_array($current_page, ['transport-cost-optimization']) ? 'bg-white/10' : ''; ?>" onclick="toggleModule('reports')">
                <div class="flex items-center gap-3">
                    <i class="fas fa-chart-bar"></i>
                    <span class="font-semibold">Transport Cost Analysis</span>
                </div>
                <i class="fas fa-chevron-down transition-transform duration-300 <?php echo in_array($current_page, ['transport-cost-optimization']) ? 'rotate-180' : ''; ?>" id="reports-icon"></i>
            </div>
            <div class="<?php echo in_array($current_page, ['transport-cost-optimization']) ? '' : 'hidden'; ?> bg-white/5 overflow-hidden transition-all duration-300" id="reports-submenu">
                <a href="<?php echo $base_url; ?>/module_4/transport-cost-optimization.php" class="nav-item text-white/70 px-5 py-2.5 pl-14 flex items-center gap-3 cursor-pointer transition-all duration-300 border-l-3 border-transparent hover:bg-white/10 hover:text-white <?php echo $current_page === 'transport-cost-optimization' ? 'bg-white/15 border-l-white text-white' : ''; ?>">
                    <i class="fas fa-file-alt text-sm"></i>
                    <span class="text-sm">Transport Cost & Optimization</span>
                </a>
            </div>
        </div>

        <div class="mt-6 mx-4 mb-4">
            <div class="bg-white bg-opacity-10 rounded-lg p-4 text-center">
                <i class="fas fa-headset text-white text-2xl mb-2"></i>
                <div class="text-white text-sm font-semibold">Need Help?</div>
                <div class="text-white text-opacity-70 text-xs mt-1">Contact support team</div>
                <a href="../ADMIN/contact-support.php" class="w-full mt-3 px-4 py-2 bg-red-500/80 text-white rounded-md text-sm font-semibold hover:bg-red-600 transition-all duration-300 flex items-center justify-center gap-2">
                     <i class="fas fa-phone-alt"></i> Contact Support
                </a>
            </div>
        </div>
    </nav>
</div>

<script>
function toggleModule(moduleName) {
    const submenu = document.getElementById(`${moduleName}-submenu`);
    const icon = document.getElementById(`${moduleName}-icon`);
    
    if (submenu.classList.contains('hidden')) {
        submenu.classList.remove('hidden');
        icon.classList.add('rotate-180');
    } else {
        submenu.classList.add('hidden');
        icon.classList.remove('rotate-180');
    }
}
</script>