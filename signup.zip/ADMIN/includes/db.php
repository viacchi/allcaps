<?php
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "log2_logtwo";
$port = 3307;

$conn = mysqli_connect($host, $user, $pass, $dbname, $port);
if (!$conn) die("Connection Failed: " . mysqli_connect_error());
?>