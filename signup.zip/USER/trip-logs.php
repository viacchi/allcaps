<?php
include 'includes/functions.php';
$history = getTripHistory();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Trip History</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script>
        tailwind.config = { theme: { extend: { colors: { 'primary-green': '#2D7A5C' } } } }
    </script>
</head>
<body class="bg-gray-50 font-sans">

    <?php include 'includes/sidebar.php'; ?>

    <div class="md:pl-72 transition-all duration-300 min-h-screen flex flex-col">
        <?php include 'includes/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-2">Trip History</h2>
            <p class="text-gray-500 mb-6 text-sm">Your past completed routes.</p>

            <div class="space-y-4">
                <?php if (empty($history)): ?>
                    <div class="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-300">
                        <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-400">
                            <i class="fas fa-history text-2xl"></i>
                        </div>
                        <p class="text-gray-500 font-medium">No completed trips yet.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($history as $row): 
                        $isSuccess = $row['status'] === 'Completed';
                    ?>
                    <div class="bg-white rounded-2xl p-5 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100 flex flex-col sm:flex-row gap-4">
                        <div class="flex sm:flex-col items-center justify-center bg-gray-50 rounded-xl p-3 sm:w-20 min-w-[80px]">
                            <span class="text-xs font-bold text-gray-400 uppercase"><?php echo date('M', strtotime($row['dispatch_date'])); ?></span>
                            <span class="text-xl font-bold text-gray-800"><?php echo date('d', strtotime($row['dispatch_date'])); ?></span>
                        </div>

                        <div class="flex-1">
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="font-bold text-gray-800">#<?php echo $row['tracking_id']; ?></h3>
                                <span class="text-[10px] font-bold px-2 py-1 rounded <?php echo $isSuccess ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                    <?php echo strtoupper($row['status']); ?>
                                </span>
                            </div>
                            <div class="flex items-center gap-2 text-sm text-gray-600 mb-1">
                                <i class="fas fa-map-marker-alt text-red-500"></i>
                                <span><?php echo htmlspecialchars($row['destination']); ?></span>
                            </div>
                            <p class="text-xs text-gray-400">Vehicle: <?php echo htmlspecialchars($row['plate']); ?></p>
                        </div>

                        <div class="flex items-center">
                            <button class="w-full sm:w-auto px-4 py-2 bg-gray-100 text-gray-600 rounded-lg text-xs font-bold hover:bg-gray-200 transition">
                                View Receipt
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>