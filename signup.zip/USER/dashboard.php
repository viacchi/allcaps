<?php
include 'includes/functions.php';

// 1. Fetch Standard Data
$kpi = getUserKPI();
$currentTrip = getCurrentActiveTrip();

// 2. Fetch AI Prediction (From Python Service)
$risk_level = "Normal";
$delay_prob = 0;
$action = "Continue";
$risk_color = "bg-emerald-500";
$risk_text = "text-emerald-600";
$risk_bg = "bg-emerald-50";

// Only try to connect if Python is running to avoid errors
$ai_url = "https://capstone-ai-service.onrender.com/predict_risk?rain=0";
$context = stream_context_create(['http' => ['timeout' => 1]]); // 1 second timeout

$ai_response = @file_get_contents($ai_url, false, $context);

if ($ai_response) {
    $ai_data = json_decode($ai_response, true);
    if(isset($ai_data['risk_level'])) {
        $risk_level = $ai_data['risk_level']; // "High" or "Low"
        $delay_prob = $ai_data['delay_probability'];
        $action = $ai_data['suggested_action'];
        
        if ($risk_level == "High") {
            $risk_color = "bg-red-500";
            $risk_text = "text-red-600";
            $risk_bg = "bg-red-50";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Driver Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script>
        tailwind.config = {
            theme: { extend: { colors: { 'primary-green': '#2D7A5C', 'dark-green': '#1F5240' } } }
        }
    </script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans pb-20 md:pb-0">

    <?php include 'includes/sidebar.php'; ?>

    <div class="md:pl-72 transition-all duration-300 min-h-screen flex flex-col">
        <?php include 'includes/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6">
            
            <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 mb-6 flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-bold text-gray-900">Driver Status</h2>
                    <p class="text-xs text-gray-500">Toggle your availability</p>
                </div>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" class="sr-only peer" checked>
                    <div class="w-14 h-7 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-primary-green"></div>
                    <span class="ml-3 text-sm font-bold text-primary-green">ONLINE</span>
                </label>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                
                <div class="lg:col-span-2">
                    <?php if ($currentTrip): ?>
                    <div class="flex justify-between items-end mb-2">
                        <h3 class="font-bold text-gray-700">Current Trip</h3>
                        <span class="text-xs text-primary-green font-bold animate-pulse">● Live Tracking</span>
                    </div>
                    
                    <div class="bg-gradient-to-br from-primary-green to-dark-green rounded-2xl p-5 text-white shadow-lg relative overflow-hidden h-full">
                        <div class="absolute top-0 right-0 p-4 opacity-10">
                            <i class="fas fa-map-marked-alt text-9xl"></i>
                        </div>
                        
                        <div class="relative z-10 flex flex-col h-full justify-between">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="text-emerald-100 text-xs uppercase tracking-wide font-bold">Ref: #<?php echo $currentTrip['tracking_id']; ?></p>
                                    <h2 class="text-2xl font-bold mt-1 leading-tight"><?php echo htmlspecialchars($currentTrip['start_location']); ?> <i class="fas fa-arrow-right text-sm mx-1"></i> <?php echo htmlspecialchars($currentTrip['destination']); ?></h2>
                                </div>
                                <span class="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-lg text-xs font-bold"><?php echo $currentTrip['status']; ?></span>
                            </div>

                            <div class="mt-6 flex gap-4">
                                <div class="flex-1 bg-white/10 rounded-xl p-3 backdrop-blur-sm">
                                    <p class="text-[10px] text-emerald-100 uppercase">Vehicle</p>
                                    <p class="text-lg font-bold"><?php echo htmlspecialchars($currentTrip['plate']); ?></p>
                                </div>
                                <div class="flex-1 bg-white/10 rounded-xl p-3 backdrop-blur-sm">
                                    <p class="text-[10px] text-emerald-100 uppercase">Dispatch Time</p>
                                    <p class="text-lg font-bold"><?php echo date('h:i A', strtotime($currentTrip['dispatch_date'])); ?></p>
                                </div>
                            </div>

                            <div class="mt-4 pt-4 border-t border-white/20">
                                <a href="live-tracker.php" class="w-full bg-white text-primary-green font-bold py-3 rounded-xl hover:bg-gray-100 transition shadow-sm text-center block">
                                    <i class="fas fa-map-marker-alt mr-2"></i> View Map
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 text-center h-full flex flex-col items-center justify-center">
                        <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-3 text-gray-300">
                            <i class="fas fa-route text-3xl"></i>
                        </div>
                        <h3 class="font-bold text-gray-800">No Active Trips</h3>
                        <p class="text-sm text-gray-500">Wait for dispatch or check your schedule.</p>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="lg:col-span-1">
                    <div class="flex justify-between items-end mb-2">
                        <h3 class="font-bold text-gray-700">AI Risk Assessment</h3>
                        <span class="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded font-bold">PYTHON ML</span>
                    </div>

                    <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 h-full flex flex-col justify-between">
                        <div>
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Delay Probability</p>
                                    <h2 class="text-3xl font-extrabold <?php echo $risk_text; ?>"><?php echo $delay_prob; ?>%</h2>
                                </div>
                                <div class="w-12 h-12 <?php echo $risk_color; ?> text-white rounded-xl flex items-center justify-center text-xl shadow-lg shadow-gray-200">
                                    <i class="fas fa-brain"></i>
                                </div>
                            </div>
                            
                            <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden mb-4">
                                <div class="h-full <?php echo $risk_color; ?>" style="width: <?php echo $delay_prob; ?>%"></div>
                            </div>

                            <div class="<?php echo $risk_bg; ?> p-3 rounded-xl border border-gray-100">
                                <p class="text-xs font-bold text-gray-500 uppercase mb-1">AI Recommendation</p>
                                <div class="flex items-center gap-2 font-bold <?php echo $risk_text; ?>">
                                    <?php if($action == "Reroute"): ?>
                                        <i class="fas fa-exclamation-triangle"></i> Reroute Suggested
                                    <?php else: ?>
                                        <i class="fas fa-check-circle"></i> Safe to Proceed
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <p class="text-[10px] text-gray-400 mt-4 text-center">Powered by Scikit-Learn Random Forest</p>
                    </div>
                </div>

            </div>

            <h3 class="font-bold text-gray-700 mb-3">Overview</h3>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                    <div class="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center text-lg mb-2">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $kpi['upcoming_trips']; ?></span>
                    <span class="text-xs text-gray-500">Active/Pending</span>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                    <div class="w-10 h-10 bg-green-50 text-green-600 rounded-full flex items-center justify-center text-lg mb-2">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $kpi['completed_trips']; ?></span>
                    <span class="text-xs text-gray-500">Completed</span>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                    <div class="w-10 h-10 bg-yellow-50 text-yellow-600 rounded-full flex items-center justify-center text-lg mb-2">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $kpi['safety_score']; ?>%</span>
                    <span class="text-xs text-gray-500">Safety</span>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                    <div class="w-10 h-10 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center text-lg mb-2">
                        <i class="fas fa-gas-pump"></i>
                    </div>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $kpi['fuel_used']; ?>L</span>
                    <span class="text-xs text-gray-500">Fuel Used</span>
                </div>
            </div>

        </main>
    </div>
</body>
</html>