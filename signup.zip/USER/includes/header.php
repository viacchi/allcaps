<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Load functions if not already loaded
if (!function_exists('getUserNotifications')) {
    require_once __DIR__ . '/functions.php'; 
}

$user = $_SESSION['user'] ?? ['full_name' => 'Guest Driver', 'role' => 'Driver'];
$initial = strtoupper(substr($user['full_name'], 0, 1));

// Get Notifications (Optional: Uncomment if DB is ready)
// $notifications = getUserNotifications();
$unreadCount = 0; // count($notifications);
?>

<header class="h-16 flex items-center justify-between px-4 sm:px-6 relative shadow-md z-30" 
        style="background: linear-gradient(135deg, #2D7A5C 0%, #1F5240 100%);">
    
    <div class="flex items-center gap-3">
        <button onclick="toggleSidebar()" class="md:hidden w-10 h-10 rounded-xl hover:bg-white/10 text-white flex items-center justify-center transition">
            <i class="fas fa-bars text-lg"></i>
        </button>
        <h1 class="text-lg font-bold text-white hidden sm:block">Driver Portal</h1>
    </div>

    <div class="flex items-center gap-3 sm:gap-5">
        
        <div id="real-time-clock" class="hidden sm:block text-xs font-bold text-white/90 bg-white/10 px-3 py-2 rounded-lg border border-white/20 font-mono">
            00:00:00 AM
        </div>

        <button class="w-10 h-10 rounded-xl hover:bg-white/10 text-white transition flex items-center justify-center relative">
            <i class="fas fa-bell"></i>
            <?php if ($unreadCount > 0): ?>
            <span class="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-red-500 border-2 border-white"></span>
            <?php endif; ?>
        </button>

        <div class="h-8 w-px bg-white/20 hidden sm:block"></div>

        <div class="relative">
            <button onclick="toggleUserMenu()" class="flex items-center gap-3 focus:outline-none group rounded-xl px-2 py-1 hover:bg-white/10 transition">
                <div class="w-9 h-9 rounded-full bg-white text-[#2D7A5C] flex items-center justify-center font-bold shadow-sm">
                    <?php echo $initial; ?>
                </div>
                <div class="hidden md:flex flex-col items-start text-left">
                    <span class="text-sm font-bold text-white group-hover:text-gray-100 transition-colors">
                        <?php echo htmlspecialchars($user['full_name']); ?>
                    </span>
                    <span class="text-[10px] text-white/70 font-medium uppercase">
                        <?php echo htmlspecialchars($user['role']); ?>
                    </span>
                </div>
                <i class="fas fa-chevron-down text-white/70 text-xs ml-1 group-hover:text-white"></i>
            </button>

            <div id="user-menu-dropdown" class="hidden absolute right-0 mt-3 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 transform origin-top-right transition-all">
                <a href="#" class="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#2D7A5C] transition">
                    <i class="fas fa-user-circle mr-2"></i> My Profile
                </a>
                <a href="#" class="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#2D7A5C] transition">
                    <i class="fas fa-cog mr-2"></i> Settings
                </a>
                <div class="h-px bg-gray-100 my-1"></div>
                <a href="../logout.php" class="block px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>
    </div>
</header>

<script>
    function toggleUserMenu() {
        const menu = document.getElementById('user-menu-dropdown');
        menu.classList.toggle('hidden');
    }
    
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        
        // Simple toggle for mobile
        if (sidebar.classList.contains('-translate-x-full')) {
            sidebar.classList.remove('-translate-x-full');
            if(overlay) {
                overlay.classList.remove('hidden');
                setTimeout(() => overlay.classList.remove('opacity-0'), 10);
            }
        } else {
            sidebar.classList.add('-translate-x-full');
            if(overlay) {
                overlay.classList.add('opacity-0');
                setTimeout(() => overlay.classList.add('hidden'), 300);
            }
        }
    }

    // Clock
    setInterval(() => {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const clock = document.getElementById('real-time-clock');
        if(clock) clock.innerText = timeString;
    }, 1000);

    // Close dropdowns
    document.addEventListener('click', function(e) {
        const menu = document.getElementById('user-menu-dropdown');
        const btn = document.querySelector('button[onclick="toggleUserMenu()"]');
        if (menu && !menu.classList.contains('hidden') && !menu.contains(e.target) && !btn.contains(e.target)) {
            menu.classList.add('hidden');
        }
    });
</script>