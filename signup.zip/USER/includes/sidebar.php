<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div id="sidebar-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-black/30 hidden opacity-0 transition-opacity duration-300 z-40 md:hidden"></div>

<aside id="sidebar" class="fixed top-0 left-0 h-full w-72 text-white shadow-xl z-50 transform -translate-x-full md:translate-x-0 transition-transform duration-300" 
       style="background: linear-gradient(180deg, #2D7A5C 0%, #1F5240 100%);">

    <div class="h-16 flex items-center px-6 border-b border-white/10">
        <a href="dashboard.php" class="flex items-center gap-3 w-full group">
            <div class="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center font-bold text-xl text-white">
                <i class="fas fa-truck-fast"></i>
            </div>
            <div class="leading-tight">
                <div class="font-bold text-white tracking-wide">Logistics II</div>
                <div class="text-[10px] text-white/70 font-semibold uppercase tracking-wider">Driver Portal</div>
            </div>
        </a>
    </div>

    <div class="px-4 py-6 overflow-y-auto h-[calc(100%-4rem)] custom-scrollbar">
        
        <div class="text-[10px] font-bold text-white/40 tracking-widest uppercase px-3 mb-2">Main Menu</div>

        <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-home w-5 text-center"></i>
            Dashboard
        </a>

        <div class="text-[10px] font-bold text-white/40 tracking-widest uppercase px-3 mt-6 mb-2">Trips & Navigation</div>

        <a href="assigned-trips.php" class="<?php echo $current_page == 'assigned-trips.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-map-marked-alt w-5 text-center"></i>
            Assigned Trips
        </a>

        <a href="live-tracker.php" class="<?php echo $current_page == 'live-tracker.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-location-arrow w-5 text-center"></i>
            Live Route
        </a>

        <a href="trip-logs.php" class="<?php echo $current_page == 'trip-logs.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-clipboard-list w-5 text-center"></i>
            Trip History
        </a>

        <div class="text-[10px] font-bold text-white/40 tracking-widest uppercase px-3 mt-6 mb-2">Vehicle & Safety</div>

        <a href="routine-check.php" class="<?php echo $current_page == 'routine-check.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-tasks w-5 text-center"></i>
            Routine Check
        </a>

        <a href="fuel-updates.php" class="<?php echo $current_page == 'fuel-updates.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-gas-pump w-5 text-center"></i>
            Fuel Logs
        </a>

        <a href="incident-reporting.php" class="<?php echo $current_page == 'incident-reporting.php' ? 'bg-red-500/20 text-red-100 shadow-lg' : 'text-white/80 hover:bg-red-500/20 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-exclamation-triangle w-5 text-center"></i>
            Report Incident
        </a>

        <a href="driver-contact.php" class="<?php echo $current_page == 'driver-contact.php' ? 'bg-white/20 text-white shadow-lg' : 'text-white/80 hover:bg-white/10 hover:text-white'; ?> flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium mb-1">
            <i class="fas fa-headset w-5 text-center"></i>
            Contact Support
        </a>

        <div class="mt-8 pt-6 border-t border-white/10">
            <a href="../logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-red-300 hover:bg-red-500/20 hover:text-red-200 transition-all duration-200 font-medium">
                <i class="fas fa-sign-out-alt w-5 text-center"></i>
                Logout
            </a>
        </div>

    </div>
</aside>